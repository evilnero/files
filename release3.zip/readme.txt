Simple hotkey script for trade/inventory/stash clicking for Path of Exile [clicker].

Keys NOT on Numpad:
CTRL + 2 (same as 1-4 on numpad): click and move mouse 1 position lower
CTRL + 3: hold it to click mouse multuple times at minimum delay (similar to scroller button clicker some people use, when they assign mouse click there)
CTRL + SHIFT + 3: same CTRL + 3, but shift is holding, which is useful for some actions like buying multiple stacked items from vendors.

Hotkeys (these are on Numpad):
CTRL + 0: move a mouse to your inventory's first position.
CTRL + 1-4: click and move mouse 1 position lower
CTRL + 5: click and move mouse 1 position to the right and on top
CTRL + 7-9: just clicks a mouse 1 time

So, generally, you can click 60 stacks faster, because you're pressing not 1 mouse button, but 5 keyboard buttons
or just hold CTRL + 3 (not numpad) and move mouse over everything you need to click.

If using method 2, start with CTRL+0 if you need to move to position 1:1, then repeat CTRL+1,2,3,4,5 until you're done.
You can start in any other position if you're not pressing 0.
7,8,9 are used to move stuff stacked in your (premium) stash tabs fast. Here too, you're using 3 keys instead of 1.
This is designed for 1920-1080 resolution. If need others, you'll need to adjust coordinates and recomplite or start it with AutoHotkey (can recommend an editor here: Scite for AutoHotkey).

//
Support/Donate...
I am from Russia, so getting donates/money from other countries here is difficult these days.
But if you'd like to support, here is my
Ozon (Ozon Ekom Bank) card (Russian card system MIR, not VISA/Master): 2204320103596609
Can think about other options, if you'll contact me via Telegram: https://t.me/evilnero
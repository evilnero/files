Simple hotkey script for trade/inventory/stash clicking. It does not violate POE TOS, because 1 key is bound to 1 action.
Not a bot, but just some mouse movement and clicks.

Designed for 1920-1080 resolution. If you need others, you'll need to adjust coordinates and recomplite/start it with Autohotkey (I can also recommend a script editor there: Scite for AutoHotkey).

Hotkeys (these are on Numpad keys):

CTRL + 0: move a mouse to your inventory's first position.
CTRL + 1-4: click and move mouse 1 position lower
CTRL + 5: Click and move mouse 1 position to the right and on top
CTRL + 6: (deprecated) sends CTRL UP (unpresses CTRL)
CTRL + 7-9: just clicks a mouse 1 time

So, generally, you can move 60 positions faster, because you're pressing not 1 mouse button, but 5 keyboard buttons.
Start with 0 if you need to move to position 1:1, then repeat 1-5 until you're done.
You can start with any other position if you're not pressing 0.
7,8,9 are used to move stuff from your stash fast. Here as well, you're using 3 keys instead of 1.

Maybe it would work better if you'll set high process priority.

//

I am from Russia, so getting some money from other countries is there is difficult these days.
But if you'd like to support, here is my
Ozon (Ozon Ekom Bank) card (Russian card system MIR, not VISA/Master): 2204320103596609
Can try thinking about other options, if you'll contact me via Telegram: https://t.me/evilnero